## Supaplex Levelset 10

### Levelset changes
2001-08-06 -- v1.0 -- Initial release (69+1 levels)

2003-10-08 -- v2.0 -- [AlterT] Remove level 70 (made by Jussi Sipola, saved as 'pipes.sp'), add 42 more levels

2005-04-23 -- v2.1 -- [Ahn Young-Seob] Fix level 105 (add exit) and level 109 (move 2 infotrons) to be solvable

### Credits

Level(s) | Author | Email | Notes
--------:|:------ |:----- |:-----
001-111  | AlterT |       |
