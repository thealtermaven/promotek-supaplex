## Supaplex Levelset 10 -- Canonical solutions


### Notes
Design of level 12 is too unclear and broken in several ways, so it's unclear which soution should be canonical.
A solution by HPerk looks like the best one, because it doesn't destroy the gravity ports.
