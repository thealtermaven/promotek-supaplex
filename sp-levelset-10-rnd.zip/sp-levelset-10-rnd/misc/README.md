pipes.sp -- old level 70 from levelset 10 v1.0

spset10.txt -- the official description of leveset 10 v2.x
s10hints.txt -- official hints for levelset 10 v2.x
